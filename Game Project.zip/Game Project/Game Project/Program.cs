﻿//From line 2 to 3 : - We are using the 'using' directives. Which help to import the namespace. The name space will contain the class and methods"
using System;
using System.IO;


//From lines 7 to 11, we are going to define the class and the variable that we are going to use in the below codes.
class GameProject 
{
    static Random random = new Random();
    static int total = 0;
    static int correct = 0;


    // From lines 17 to 23: We are going to define some more variables, which are going to be part of the code. Also, created one more list as a gameResults as a string.
    static void Main()
    {
        List<string> gameResults = new List<string>();
        string InputQuestionFilename = "GamingQuiz.txt";
        string[] QuestionsInput = File.ReadAllLines(InputQuestionFilename);
        string EnterPassword;
        string ReEnterPassword;
        string UserName;
        int AttemptforCorrectPassword = 3;



        //From line 28 to 29:- we are defining the user's name for the game in the project.
        Console.WriteLine("Welcome users to this game \n \nPlease enter your name: ");
        string userName = Console.ReadLine();



        //In line 34 i used to string in line and string indicator from Stack Overflow. (n.d.). Reading a string line per line in C#. [online] Available at: www.stackoverflow.com/questions/3989816/reading-a-string-line-per-line-in-c-sharp [Accessed 3 Jan. 2024].‌
        Console.WriteLine($"\nWelcome {userName} to this gaming world.");
        string userPassword = GetUserPassword();
        int attemptForCorrectPassword = 3;


        //From lines 40 to 56, we are using the while loop along with break functionality.In this while loop, we are also reducing the attempt count with the decrement operator.
        while (attemptForCorrectPassword > 0)
        {
            if (Login(userPassword))
            {
                Console.WriteLine("\nCongratulations on logging in successfully! Let's enter the gaming matrix\n\n");
                break;
            }
            else
            {
                Console.WriteLine($"\nSorry! Please try again because your login credentials are not matched. Also, you have {--attemptForCorrectPassword} chance(s) remaining\n\n");
            }
        }

        if (attemptForCorrectPassword == 0)
        {
            Console.WriteLine("\nLogin failed. Exiting the program.");
            return;
        }


        //From line 61 to line 89, we will run the different procedures in the main procedure in which we can exceed the defined functions together. In the do -while loop, I added this feature to repeat the results every time the game is initiated.We create a game result in which I capture the result, and with the add function, we can add every result that occurs in every game that has been played by the users.        do
        do
        {
            questionCondition();
            GetFeedback();
            UsersResultOutput(userName);

            string gameResult = $"{userName}'s result: {CorrectAnswersscore()} out of {Totalscore()}";
            gameResults.Add(gameResult);

            Console.WriteLine("Do you want to play again? (Yes/Y or No/N): ");
            string replayChoice = Console.ReadLine();

            if ((replayChoice == "Yes") || (replayChoice == "Y" ))
            {
                total = 0;
                correct = 0;
            }
            else
            {
                Console.WriteLine("Thank you for participating in the quiz game!");

                SaveGameResults(gameResults);

                break;
            }

        } while(true);

    }
    
        
    //The condition used in the below line has been derived from the unit 7 procedure "Define Procedure" concept.
    //From lines 94 to 97, we are going to define the total feature, in which we are using the increment operator for the total answers, which can be used in multiple programme procedures.
    static int Totalscore()
    {
        return total;   
    }

    //From lines 100 to 103, we are going to define the correct feature in which we can increment the correct answers, which can be used in multiple programme procedures.
    static int CorrectAnswersscore()
    {
        return correct;
    }


    //From line 107 to line 140, we created a question-condition procedure in which I imported all the questions and answers from a txt file.where I also use the condition, which helps fetch only those specific lines that contain questions and options. For the answer, I used an if condition, which helps to show the correct and incorrect output.After that, the condition can evaluate the score and total after the completion of the quiz.
    static void questionCondition()
    {

        //The questions imported from a Txt format file and used in lines 80 to 88 are referred to in the reference "quizizz.com. (n.d.). Esports | 111 plays | Quizizz. [online] Available at: www.quizizz.com/admin/quiz/5c8ee287cb4c12001a84a8b1/esports [Accessed Jan. 1, 2024]. and "quizizz.com. (n.d.).Esports | 387 plays | Quizizz. [online] Available at: www.quizizz.com / admin / quiz / 6089e160bcd7c4001b16698f / esports ? fromSearch = true & source = [Accessed 1 Jan. 2024].\n‌";

        string InputQuestionFilename = "GamingQuiz.txt";
        string[] QuestionsInput = File.ReadAllLines(InputQuestionFilename);
        for (int i = 0; i < QuestionsInput.Length; i += 6)
        {
            Console.WriteLine(QuestionsInput[i]);
            Console.WriteLine(QuestionsInput[i + 1]);
            Console.WriteLine(QuestionsInput[i + 2]);
            Console.WriteLine(QuestionsInput[i + 3]);
            Console.WriteLine(QuestionsInput[i + 4]);
            Console.WriteLine("Select your Answer: ");
            string selectedanswer = (Console.ReadLine());
            if ("Solution:" + selectedanswer == (QuestionsInput[i + 5]))
            {
                Console.WriteLine("Correct!\n");
                correct++;
            }
            else
            {
                Console.WriteLine("Incorrect\n ");

            }
            total++;

        }
        
        Console.WriteLine($"For the Quiz, your total score is {CorrectAnswersscore()} Out of {Totalscore()}");
        Console.ReadLine();

    }


    //From lines 144 to 152, In the below procedure, we are going to define the file output feature, where this function can output the user's score of one game to a text file in the project bin.
    static void UsersResultOutput(string userName)
    {
        using (StreamWriter FileData = new StreamWriter("UserData.txt"))
        {
            FileData.WriteLine($"The score of the {userName} is {CorrectAnswersscore()} Out of {Totalscore()}");
            FileData.Close();
        }
    }


    //From lines 155 to 169, we are defining the feedback condition with the "If else" statement to get an output as per condition-based.
    static void GetFeedback()
    {
        Console.WriteLine("Thank you for taking the part in this quiz game. I hope you like it please select (Yes/Y or No/N) for the feedback in below question \n Have you like the quiz?");
        string Feedback = Console.ReadLine();
        if (Feedback == "Yes" || Feedback == "Y")
        {
            Console.WriteLine("We appreciate your positive feedback. Please play again with us. ");
        }
        else if (Feedback == "No" || Feedback == "N")
        {
            Console.WriteLine("We appreciate your feedback. We try to improve the user's experience in the next version. ");
        }
        Console.ReadLine();
    }


    //From lines 172 to 178, we are creating the login procedure, where we define that the re-entered password should be equal to the entered password.To validate that, if the re-entered password is not equal to the entered password, then the code will show an error. 
    static bool Login(string enteredPassword)
    {
        Console.WriteLine("\nPlease enter the password to be a part of Gaming Matrix");
        string reEnterPassword = Console.ReadLine();
        return reEnterPassword == enteredPassword;
    }


    //From lines 181 to 197, we are creating the password as well as the repeating password.First, we are going to define the string variable that we are going to use with the help of the "do while" loop.
    static string GetUserPassword()
    {
        string enterPassword, reEnterPassword;

        do
        {
            Console.WriteLine("\nPlease create your password to get access to the gaming world.");
            Console.WriteLine("\nEnter your password to generate your password: ");
            enterPassword = Console.ReadLine();

            Console.WriteLine("\nCan you repeat your password to generate your unique password? ");
            reEnterPassword = Console.ReadLine();
        } while (enterPassword != reEnterPassword);

        return enterPassword;
    }
     

    // From Line 200 to 211 - The reference for foreach loop fuctionlaity is been taken from Stack Overflow. (n.d.). How to get the sum of List object property values using foreach. [online] Available at: www.stackoverflow.com/questions/23891682/how-to-get-the-sum-of-list-object-property-values-using-foreach.
    static void SaveGameResults(List<string> results)
    {
        using (StreamWriter fileData = new StreamWriter("AllGameResults.txt"))
        {
            foreach (string result in results)
            {
                fileData.WriteLine(result);
            }
            fileData.Close();
        }
    }
}

